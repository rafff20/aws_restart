print("Count to 10!")
for x in range (11):
    print(x)
    
test = "AWS Restart"
for x in test:
    print(f"huruf pembuat {x}")