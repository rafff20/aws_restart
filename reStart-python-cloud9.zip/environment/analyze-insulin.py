var1 = open('/home/ec2-user/environment/prepoinsulin-seq.txt', 'r')
var1 = var1.read()
print(var1)

char=["ORIGIN", "//"," ","\n","1","2","3","4","5","6","7","8","9","0"]
for x in char:
    var1=var1.replace(x,"")
print(var1)
print(len(var1))

# simpan di prepoinsulin-seq-clean.txt
file = open("prepoinsulin-seq-clean.txt",'w')
file.write(var1)

# simpan di lsinsulin-seq-clean.txt (1-24) di terjemahkan dalam bentuk indeks 0:23
a=var1[89:]
print(a)
print(len(a))
file = open("ainsulin-seq-clean.txt",'w')
file.write(a)

# simpan di lsinsulin-seq-clean.txt (1-24) di terjemahkan dalam bentuk indeks 0:23
c=var1[54:89]
print(c)
print(len(c))
file = open("cinsulin-seq-clean.txt",'w')
file.write(c)

