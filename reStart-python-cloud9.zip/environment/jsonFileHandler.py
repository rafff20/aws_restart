import json

# '/home/ec2-user/environment/insulin.json'
def readJsonFile(fileName):
    data = ""
    try:
        with open(fileName) as json_file:
            data = json.load(json_file)
            print(data)
    except IOError:
        print("Could not read file")
    return data
    
    
# readJsonFile("/home/ec2-user/environment/insulin.json")