import os
import subprocess

# os.system("ls")
# os.system("pwd")
# os.system("whoami")
# path = "/home/ec2-user/environment"
# os.listdir(path)


# subprocess.run(["touch", "testfile"])
# subprocess.run(["ls"])

command="uname"
commandArgument="-a"
print(f'Gathering system information with command: {command} {commandArgument}')
subprocess.run([command,commandArgument])

command="ps"
commandArgument="-x"
print(f'Gathering active process information with command: {command} {commandArgument}')
subprocess.run([command,commandArgument])