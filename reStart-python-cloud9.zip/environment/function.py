# def getDoubleAlphabet(alphabet):
#     doubleAlphabet = alphabet + alphabet
#     return doubleAlphabet
    
# # alphabet="ABC"
# # print(getDoubleAlphabet(alphabet))

# def getMessage():
#     stringToEncrypt = input("Please enter a message to encrypt: ")
#     return stringToEncrypt
    
# # print(getMessage())

# def getCipherKey():
#     shiftAmount = input( "Please enter a key (whole number from 1-25): ")
#     return shiftAmount

# # print(getCipherKey())

# def encryptMessage(message, cipherKey, alphabet):
#     encryptedMessage = ""
#     uppercaseMessage = ""
#     uppercaseMessage = message.upper()
#     print("encryptedMessage "+ encryptedMessage)
#     print("uppercaseMessage "+uppercaseMessage+"\n")
#     for currentCharacter in uppercaseMessage:
#         position = alphabet.find(currentCharacter)
#         newPosition = position + int(cipherKey)
#         print("currentCharacter " + currentCharacter)
#         print("position " + str(position)+ " newPosition "+str(newPosition))
#         if currentCharacter in alphabet:
#             encryptedMessage = encryptedMessage + alphabet[newPosition]
#             print("encryptedMessage "+encryptedMessage+"\n")
#         else:
#             encryptedMessage = encryptedMessage + currentCharacter
#             print("encryptedMessage "+encryptedMessage+"\n")
#     return encryptedMessage

# encryptMessage("abi_1", 3, "ABCDEFGHIJKL")

# -------------------------------------------------------------
# def encryptMessage(message, cipherKey, alphabet):      #encryptMessage("Abi", 3, "ABCDEFGHIJKL")
#     encryptedMessage = ""
#     uppercaseMessage = ""
#     uppercaseMessage = message.upper()                  #uppercaseMessage=ABI
#     print("encryptedMessage "+encryptedMessage)
#     print("uppercaseMessage "+uppercaseMessage+"\n")
#     for currentCharacter in uppercaseMessage:           #loop 3x
#         position = alphabet.find(currentCharacter)
#         newPosition = position + int(cipherKey)
#         print("currentCharacter "+currentCharacter)
#         print("position "+str(position)+ " newPosition "+str(newPosition))
#         if currentCharacter in alphabet:
#             encryptedMessage = encryptedMessage + alphabet[newPosition]
#             print("encryptedMessage "+encryptedMessage +"\n")
#         else:
#             encryptedMessage = encryptedMessage + currentCharacter
#             print("encryptedMessage "+encryptedMessage +"\n")
#     return encryptedMessage

# encryptMessage("Abi_1", 3, "ABCDEFGHIJKL")

# --------------------------------------

def getDoubleAlphabet(alphabet):
    doubleAlphabet = alphabet + alphabet
    return doubleAlphabet
    
def getMessage():
    stringToEncrypt = input("Please enter a message to encrypt: ")
    return stringToEncrypt
    
def getCipherKey():
    shiftAmount = input( "Please enter a key (whole number from 1-25): ")
    return shiftAmount

def encryptMessage(message, cipherKey, alphabet):
    encryptedMessage = ""
    uppercaseMessage = ""
    uppercaseMessage = message.upper()
    for currentCharacter in uppercaseMessage:
        position = alphabet.find(currentCharacter)
        newPosition = position + int(cipherKey)
        if currentCharacter in alphabet:
            encryptedMessage = encryptedMessage + alphabet[newPosition]
        else:
            encryptedMessage = encryptedMessage + currentCharacter
    return encryptedMessage


def decryptMessage(message, cipherKey, alphabet):
    decryptKey = -1 * int(cipherKey)
    return encryptMessage(message, decryptKey, alphabet)

def runCaesarCipherProgram():
    myAlphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    print(f'Alphabet: {myAlphabet}')
    myAlphabet2 = getDoubleAlphabet(myAlphabet)
    print(f'Alphabet2: {myAlphabet2}')
    myMessage = getMessage()
    print(myMessage)
    myCipherKey = getCipherKey()
    print(myCipherKey)
    myEncryptedMessage = encryptMessage(myMessage, myCipherKey, myAlphabet2)
    print(f'Encrypted Message: {myEncryptedMessage}')
    myDecryptedMessage = decryptMessage(myEncryptedMessage, myCipherKey, myAlphabet2)
    print(f'Decypted Message: {myDecryptedMessage}')
    
runCaesarCipherProgram()